import React, { Component } from 'react';
import './App.css';

class Snacks extends Component {
  render() {
    return (
      <h2>Snacks page!</h2>
    );
  }
}

export default Snacks;
import React, { Component } from 'react';
import './App.css';

class Drinks extends Component {
  render() {
    return (
      <h2>Drinks page!</h2>
    );
  }
}

export default Drinks;
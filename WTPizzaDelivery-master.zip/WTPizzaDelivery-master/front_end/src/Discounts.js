import React, { Component } from 'react';
import './App.css';

class Discounts extends Component {
  render() {
    return (
      <h2>Discounts page!</h2>
    );
  }
}

export default Discounts;
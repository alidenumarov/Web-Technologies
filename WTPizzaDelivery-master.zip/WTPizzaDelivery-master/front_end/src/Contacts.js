import React, { Component } from 'react';
import './App.css';

class Contacts extends Component {
  render() {
    return (
      <h2>Contacts page!</h2>
    );
  }
}

export default Contacts;
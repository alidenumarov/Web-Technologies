# WTPizzaDelivery
The description, Class diagram and Moqup of the project are in front_end folder.

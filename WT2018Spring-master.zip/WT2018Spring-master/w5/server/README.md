
## NodeJS server example


### Usage
- enter to rood folder of project
```shell
cd /path/server
```
- run npm install command to install dependencies
```shell
npm install
```
- run your server
```shell
node server.js
```
- find your app in the browser
```shell
http://localhost:3000/
```
